"""
Vision Tool Registry.
"""

from __future__ import annotations

from collections.abc import ItemsView
from typing import Type

from openvisionx.core.base_tool import BaseTool


class ToolRegistry:

    _tools: dict[str, Type[BaseTool]] = {}

    @classmethod
    def register(
        cls,
        tool_cls: Type[BaseTool],
    ) -> Type[BaseTool]:

        tool_id = tool_cls.METADATA.id

        if tool_id in cls._tools:
            raise ValueError(
                f"Tool '{tool_id}' already registered."
            )

        cls._tools[tool_id] = tool_cls

        return tool_cls

    @classmethod
    def create(
        cls,
        tool_id: str,
    ) -> BaseTool:

        return cls._tools[tool_id]()

    @classmethod
    def contains(
        cls,
        tool_id: str,
    ) -> bool:

        return tool_id in cls._tools

    @classmethod
    def names(
        cls,
    ) -> list[str]:

        return sorted(cls._tools.keys())

    @classmethod
    def items(
        cls,
    ) -> ItemsView[str, Type[BaseTool]]:

        return cls._tools.items()

    @classmethod
    def clear(
        cls,
    ) -> None:

        cls._tools.clear()