"""
Vision Tool Metadata.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class ToolMetadata:
    """
    Tool description used by Studio.
    """

    id: str
    display_name: str
    category: str
    description: str = ""
    icon: str = ""