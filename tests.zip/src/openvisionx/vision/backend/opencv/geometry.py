"""
OpenCV geometry operations.
"""

from __future__ import annotations

from openvisionx.data import Image
from openvisionx.geometry import Rectangle

from openvisionx.data import PixelFormat


def crop(
    image: Image,
    rectangle: Rectangle,
) -> Image:
    """
    Crop image by rectangle.
    """

    x = int(rectangle.x)
    y = int(rectangle.y)
    w = int(rectangle.width)
    h = int(rectangle.height)

    roi = image.mat[
        y:y + h,
        x:x + w,
    ]

    return Image(
        mat=roi.copy(),
        pixel_format=image.pixel_format,
    )