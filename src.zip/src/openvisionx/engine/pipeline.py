"""
Pipeline implementation.
"""

from __future__ import annotations

from time import perf_counter

from openvisionx.core.execution_context import ExecutionContext
from openvisionx.core.logger import get_logger
from openvisionx.core.metadata import Metadata

from .pipeline_result import PipelineResult
from .pipeline_status import PipelineStatus
from .tool_collection import ToolCollection


class Pipeline:
    """
    Execute a sequence of Tools.
    """

    def __init__(
        self,
        *,
        name: str = "Pipeline",
    ) -> None:

        self.metadata = Metadata(
            name=name,
        )

        self.tools = ToolCollection()

        self.logger = get_logger(name)

        self.enabled = True

    @property
    def name(self) -> str:
        return self.metadata.name

    def add(self, tool) -> "Pipeline":
        """
        Add a tool.

        Returns
        -------
        Pipeline
            Return self to support fluent API.
        """

        self.tools.add(tool)

        return self

    def remove(self, tool) -> None:

        self.tools.remove(tool)

    def clear(self) -> None:

        self.tools.clear()

    def __len__(self) -> int:

        return len(self.tools)

    def run(
        self,
        context: ExecutionContext,
    ) -> PipelineResult:
        """
        Execute the pipeline.
        """

        result = PipelineResult()

        if not self.enabled:

            result.status = PipelineStatus.CANCELLED

            result.message = "Pipeline disabled."

            return result

        self.logger.info("Pipeline started.")

        started = perf_counter()

        try:

            result.status = PipelineStatus.RUNNING

            for tool in self.tools:

                tool.run(context)

            result.status = PipelineStatus.SUCCESS

        except Exception as ex:

            self.logger.exception(ex)

            result.status = PipelineStatus.FAILED

            result.message = str(ex)

        finally:

            result.elapsed_ms = (
                perf_counter() - started
            ) * 1000

            self.logger.info(
                "Pipeline finished in %.2f ms",
                result.elapsed_ms,
            )

        return result